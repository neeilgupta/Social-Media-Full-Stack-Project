import java.io.*;

public class FileDatabase implements DataBaseInterface{
    private static final String FILE_PATH = "users/"; //denotes the file(MAY BE CHANGED LATER)

    public FileDatabase() { //constructor
        File directory = new File(FILE_PATH);
    }

    @Override
    public void storeUser(User user) {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH + user.getUsername() + ".ser" ))) {
            oos.writeObject(user); //this write serialized object to file
            System.out.println("User " + user.getUsername() + " saved successfully"); //allows database to hold onto the User
        }
        catch(IOException e) {
            System.out.println("An error occurred while saving user");
            e.printStackTrace();
        }
    }

    @Override
    public User retrieveUser(String username) {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(FILE_PATH + username + ".ser"))) {
            User user = (User) ois.readObject();
            System.out.println("User " + username + " retrieved successfully.");
            return user;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("An error occurred while saving user");
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void updateUser(User user) {
        // To update a user, overwrite the file with the new updated user object
        storeUser(user);
    }


}
