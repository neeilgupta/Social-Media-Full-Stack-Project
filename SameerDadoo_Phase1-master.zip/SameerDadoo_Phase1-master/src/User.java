import java.util.*;
public class User {
    private final List<User> followers;
    private final List<User> blockedUsers;

    // Constructor(username, password)
    public User(String username, String password) {
        // Properties:
        this.followers = new ArrayList<>();
        this.blockedUsers = new ArrayList<>();
    }

    // Method follow(otherUser: User)
    public void follow(User otherUser) {
        // If otherUser is not blocked and otherUser is not in followers
        if (!blockedUsers.contains(otherUser) && !followers.contains(otherUser)) {
            followers.add(otherUser);
        }
    }

    // Method unfollow(otherUser: User)
    public void unfollow(User otherUser) {
        // If otherUser is in followers
        followers.remove(otherUser);
    }

    // Method block(otherUser: User)
    public void block(User otherUser) {
        // If otherUser is in followers
        followers.remove(otherUser);
        // If otherUser is not in blockedUsers
        if (!blockedUsers.contains(otherUser)) {
            blockedUsers.add(otherUser);
        }
    }

    // Method unblock(otherUser: User)
    public void unblock(User otherUser) {
        // If otherUser is in blockedUsers
        blockedUsers.remove(otherUser);
    }

}
