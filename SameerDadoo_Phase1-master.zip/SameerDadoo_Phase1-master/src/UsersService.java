public class UsersService {
    // Properties:
    private FileDatabase database;

    // Constructor(database: Database)
    public void UserService(FileDatabase database) {
        this.database = database;
    }

    // Method addUser(username: String, password: String)
    public void addUser(String username, String password) {
        // Create new User object
        User user = new User(username, password);
        // Store the User object in the database
        database.storeUser(user);
    }

    // Method searchUser(username: String): User
    public User searchUser(String username) {
        // Retrieve and return a User object by username from the database
        return database.retrieveUser(username);
    }

    // Method viewUser(username: String): User
    public User viewUser(String username) {
        // Retrieve and return User details by username from the database
        return database.retrieveUser(username);
    }

    // Method addFollower(currentUser: User, otherUser: User)
    public void addFollower(User currentUser, User otherUser) {
        // Call currentUser.follow(otherUser)
        currentUser.follow(otherUser);
        // Update follower list in the database
        database.updateUser(currentUser);
    }

    // Method removeFollower(currentUser: User, otherUser: User)
    public void removeFollower(User currentUser, User otherUser) {
        // Call currentUser.unfollow(otherUser)
        currentUser.unfollow(otherUser);
        // Update follower list in the database
        database.updateUser(currentUser);
    }

    // Method blockUser(currentUser: User, otherUser: User)
    public void blockUser(User currentUser, User otherUser) {
        // Call currentUser.block(otherUser)
        currentUser.block(otherUser);
        // Update blocked list in the database
        database.updateUser(currentUser);
    }

    // Method unblockUser(currentUser: User, otherUser: User)
    public void unblockUser(User currentUser, User otherUser) {
        // Call currentUser.unblock(otherUser)
        currentUser.unblock(otherUser);
        // Update blocked list in the database
        database.updateUser(currentUser);
    }

}
